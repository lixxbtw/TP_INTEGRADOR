#include <iostream>
#include <cstdlib>
#include "jugar.h"
#include "estadisticas.h"
#include <ctime>
#include "menu.h"
///Atencion. Solo hay una variable llamada "nombrejug1" y "nombrejug2". Ambas estan declaradas en menu.cpp
///Hay que usar solo esas dos.


using namespace std;


void gamePlay1()
{
    system("cls");
    const int TAM = 5;
    int tirada[TAM];
    int totalrondas=1;
    //int eleccion1=0;
    while (totalrondas<3){
            int eleccion1;

            imprimirNombres();
            if (totalrondas==1){
                cout << "RONDA #" << totalrondas << endl;

                generarTirada(tirada,TAM);
                mostrarTirada(tirada,TAM);
           ;}

            cout << "Como queres continuar?" <<endl;
            cout << "1 - Cambiar un numero" <<endl;
            cout << "2 - Cambiar todos los numeros" <<endl;
            cout << "3 - Terminar" <<endl;
            cin >> eleccion1;
               if (totalrondas ==3){
                    break;
                    }


            switch (eleccion1){
                case 1:
                    cambiarUnNumero(tirada);
                    totalrondas++;
                    break;
                case 2:
                    imprimirNombres();
                    totalrondas++;
                    cout << "RONDA #" << totalrondas << endl;
                    generarTirada(tirada,TAM);
                    mostrarTirada(tirada,TAM);

                    break;
                case 3:
                    totalrondas=4;
                    break;
            }
            system("pause");
            }}

    void gamePlay2(){

    system("cls");
    const int TAM = 5;
    int tirada[TAM];
    int totalrondas=1;


    while (totalrondas<3){
    int eleccion1;
    if (totalrondas==1){
        cout << "RONDA #" << totalrondas << endl;
        //imprimirNombres();
        generarTirada(tirada,TAM);
        mostrarTirada(tirada,TAM);
        }

        cout << "QUE ELECCION TOMAS?" <<endl;
        cout << "1 - CAMBIAR UN NUMERO" <<endl;
        cout << "2 - CAMBIAR TODOS LOS NUMEROS" <<endl;
        cout << "3 - FINALIZAR" <<endl;
        cin >> eleccion1;
        if (totalrondas ==3){
        break;
        }


    switch (eleccion1){
            case 1:
            cambiarUnNumero(tirada);
            totalrondas++;
            break;
            case 2:
                    totalrondas++;
                    cout << "RONDA #" << totalrondas << endl;
                    generarTirada(tirada,TAM);
                    mostrarTirada(tirada,TAM);

                    break;
            case 3:
                    totalrondas=4;
                    break;}

            system("pause");
            }}


int obtenerRandom(int tamanio)
{
    return rand()%tamanio + 1;
}

void generarTirada(int v[], int tamanio)
{
    for(int i = 0; i < tamanio; i++)
    {
        v[i] = obtenerRandom(6);

    }
}

void mostrarTirada(int v[], int tamanio)
{
    for(int i = 0; i < tamanio; i++)
    {
        cout << v[i] << " ";
    }
    cout << endl;
}

int obtenerPuntos(int v[], int tamanio){
    int puntos = 0;
    for(int i = 0; i < tamanio; i++){
        puntos += v[i];
    }
    return puntos;
}

void cambiarUnNumero(int v[]){

    int numeroCambio;
    cout << "Ingrese la posicion del Nro. a cambiar: ";
    cin>> numeroCambio;
    v[numeroCambio-1]=obtenerRandom(6);
    for (int x=0;x<5;x++){
        cout << v[x] << " ";
    }

}
int primeraJugada() {
    int j1,j2,mayor;
    j1 = obtenerRandom(6);
    j2 = obtenerRandom(6);

    cout << "Jugador 1 saco: " << j1 << endl;
    cout << "Jugador 2 saco: " << j2 << endl;

    if (j1 > j2){
        cout << "Jugador Nro 1 empieza." << endl;
        mayor = 1 ;
        system("pause");
        gamePlay1();
        }
    else if (j2 > j1){
        cout <<"Jugador Nro 2 empieza." << endl;
        mayor = 0;
        system("pause");
        gamePlay2();

        }
    else{
        cout << "Empate. Tirar de nuevo." << endl;
        j1 = obtenerRandom(6);
        j2 = obtenerRandom(6);

        }
    return (mayor);
}

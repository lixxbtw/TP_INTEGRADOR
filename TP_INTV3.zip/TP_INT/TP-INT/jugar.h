#ifndef JUGAR_H_INCLUDED
#define JUGAR_H_INCLUDED

void gamePlay1();
void gamePlay2();
int obtenerRandom(int tamanio);
void generarTirada(int v[], int tamanio);
void mostrarTirada(int v[], int tamanio);
int obtenerPuntos(int v[], int tamanio);
int primeraJugada();
void cambiarUnNumero(int v[]);


#endif // JUGAR_H_INCLUDED

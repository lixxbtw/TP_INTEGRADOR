#ifndef MENU_H_INCLUDED
#define MENU_H_INCLUDED

void menu();
void opciones();
///int guardarNombres(nombrejug1[],nombrejug2[]);
void guardarNombres(const std::string& nom1, const std::string& nom2);
void imprimirNombres();



#endif // MENU_H_INCLUDED

#ifndef ESTADISTICAS_H_INCLUDED
#define ESTADISTICAS_H_INCLUDED
#include <string>
using namespace std;

void partida_estadisticas();





#endif // ESTADISTICAS_H_INCLUDED

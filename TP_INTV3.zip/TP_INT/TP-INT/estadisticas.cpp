#include <iostream>
#include "estadisticas.h"
#include "jugar.h"
#include "menu.h"



using namespace std;

void partida_estadisticas(){
    cout <<"We are hard-working for u" << endl;
    cout << "Volviendo al menu principal...."<< endl;
    system("pause");
    menu();
    system("cls");
}

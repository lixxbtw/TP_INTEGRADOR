#include <iostream>
#include "creditos.h"
#include "menu.h"
using namespace std;


void creditos() {
    int seleccion;
    cout << "-+-+-+-+-+-+-+-+ Este fue el trabajo del equipo NRO.28 llamado B.R GAMES -+-+-+-+-+-+-+-+ " << endl;

    do {
        cout << endl;
        cout << "Selecciona un integrante del grupo para ver sus datos:" << endl;
        cout << endl;
        cout << "1. Marco Lavergne" << endl;
        cout << "2. Joaquin Pereyra" << endl;
        cout << "3. Valentin Juarez" << endl;
        cout << "0. Volver al menu principal" << endl;
        cout << endl;
        cout << "Opcion: ";
        cin >> seleccion;

        cout << endl;

        switch (seleccion) {
            case 1:
                system("cls");
                cout << "Nombre: Marco Lavergne" << endl;
                cout << "Legajo: 33440" << endl;
                cout << "DNI: 46.705.278" << endl;
                break;
            case 2:
                system("cls");
                cout << "Nombre: Joaquin Pereyra" << endl;
                cout << "Legajo: 32.886" << endl;
                cout << "DNI: 46.580.941" << endl;
                break;
            case 3:
                system("cls");
                cout << "Nombre: Valentin Juarez" << endl;
                cout << "Legajo: 32.872" << endl;
                cout << "DNI: 44.422.111" << endl;
                break;
            case 0:
                system("cls");

                menu();
                cout << "Volviendo al menu principal..." << endl;
                break;
            default:
                system("cls");
                cout << "Opcion no valida." << endl;
                break;
        }

        if (seleccion != 0) {
            system("pause");
        }
    } while (seleccion != 0);
}

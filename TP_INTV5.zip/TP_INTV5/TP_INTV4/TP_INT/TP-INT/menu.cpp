#include <iostream>
#include "menu.h"
#include "jugar.h"
#include "creditos.h"
#include "estadisticas.h"
#include <cstring>


using namespace std;
string nombrejug1;
string nombrejug2;
void menu()
{
    int seleccion;

    do
    {
        opciones(); /// Muestra el men�
        cout << "Ingrese una opcion: ";
        cin >> seleccion;

        switch(seleccion)
        {
            case 1:
                int eleccionjugador;
                system ("cls");
                cout << "INICIA EL JUEGO" << endl;
                cout << endl;
                cout << "1- UN JUGADOR "<< endl;
                cout << "2- DOS JUGADORES "<< endl;
                cin >> eleccionjugador;

                if (eleccionjugador ==1){
                    cout << "Ingrese su nombre: "<< endl;
                    cin >> nombrejug1;
                    gamePlay1();
                }
                else if (eleccionjugador ==2){
                        system("cls");
                        cout << "Ingrese el nombre del 1er jugador: ";
                        cin >> nombrejug1;
                        cout << "Ingrese el nombre del 2do jugador: ";
                        cin >> nombrejug2;

                        system("cls");
                        cout << "Quien empieza? "<<endl;
                        system("pause");
                        int mayor=primeraJugada();

                        system("pause");
                         if (mayor==1){

                            gamePlay1();
                            gamePlay2();

                            }
                        else if (mayor==2){

                            gamePlay2();
                            gamePlay1();
                            }



                }
                break;
                return;/// Sale de la funci�n menu()
            case 2:
                partida_estadisticas(); /// Estadisticas de la partida
                system("pause");
                break;
                return;/// Sale de la funci�n menu()
            case 3:
                creditos(); /// Muestra cr�ditos
                system("pause");
                return; /// Sale de la funci�n menu()
            case 0:
                cout << "Saliendo del juego..." << endl;
                exit(0); /// Termina el programa
            default:
                cout << "Opcion invalida." << endl;
                system ("pause");

                break;
        }
    } while(true);
}

void opciones()
{
    system("cls");///Funcion para dejar limpia la consola
    cout << "+-+-+-+-+-+-+-+-+-+-" << endl;
    cout << "|      YAHTICO     |" << endl;
    cout << "+-+-+-+-+-+-+-+-+-+-" << endl;
    cout << "--------------------" << endl;
    cout << "| 1- JUGAR         |" << endl;
    cout << "| 2- ESTADISTICAS  |" << endl;
    cout << "| 3- CREDITOS      |" << endl;
    cout << "--------------------" << endl;
    cout << "| 0- SALIR         |" << endl;
    cout << "--------------------" << endl;
    cout << endl;

}


void guardarNombres(const std::string& nombrejug1, const std::string& nombrejug2) {

    string nom1 = nombrejug1;
    string nom2 = nombrejug2;

}
void imprimirNombres1() {


    std::cout << "Jugador 1: " << nombrejug1 << std::endl;

}void imprimirNombres2() {



    std::cout << "Jugador 2: " << nombrejug2 << std::endl;
}


#include <iostream>
#include "estadisticas.h"
#include "jugar.h"
#include "menu.h"



using namespace std;

void partida_estadisticas(){
    cout << endl;
    cout <<"We are hard-working for u" << endl;
    cout << endl;
    cout << endl;
    cout << "Volviendo al menu principal...."<< endl;
    cout << endl;
    system("pause");
    menu();
    system("cls");
}

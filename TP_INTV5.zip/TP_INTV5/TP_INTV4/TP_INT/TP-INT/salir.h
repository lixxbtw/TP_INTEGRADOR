#ifndef SALIR_H_INCLUDED
#define SALIR_H_INCLUDED

void afuera_programa();


#endif // SALIR_H_INCLUDED

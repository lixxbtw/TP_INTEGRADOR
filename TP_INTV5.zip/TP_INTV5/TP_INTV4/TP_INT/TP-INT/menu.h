#ifndef MENU_H_INCLUDED
#define MENU_H_INCLUDED

void menu();
void opciones();
void guardarNombres(const std::string& nombrejug1, const std::string& nombrejug2);
void imprimirNombres1();
void imprimirNombres2();



#endif // MENU_H_INCLUDED

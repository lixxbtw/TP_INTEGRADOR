#ifndef CREDITOS_H_INCLUDED
#define CREDITOS_H_INCLUDED

void creditos();
void integrantes();



#endif // CREDITOS_H_INCLUDED

#include <iostream>
#include "menu.h"
#include "jugar.h"
#include "creditos.h"
#include "estadisticas.h"


using namespace std;

void menu()
{
    int seleccion;
    string nombrejug1,nombrejug2;

    do
    {
        opciones(); /// Muestra el men�
        cout << "Ingrese una opcion: "<<endl;
        cin >> seleccion;

        switch(seleccion)
        {
            case 1:
                int eleccionjugador;
                system ("cls");
                cout << "INICIA EL JUEGO" << endl;
                cout << "1- UN JUGADOR "<< endl;
                cout << "2- DOS JUGADORES "<< endl;
                cin >> eleccionjugador;

                if (eleccionjugador ==1){
                    cout << "Ingrese su nombre: "<< endl;
                    cin >> nombrejug1;
                    gamePlay1();
                }
                else if (eleccionjugador ==2){
                        system("cls");
                        cout << "Ingrese el nombre del 1er jugador: ";
                        cin >> nombrejug1;
                        cout << "Ingrese el nombre del 2do jugador: ";
                        cin >> nombrejug2;
                        system("cls");
                        cout << "Quien empieza? "<<endl;
                        system("pause");
                        primeraJugada();
                        system("pause");
                        //gamePlay1();
                        //gamePlay2();

                }
                break;
                return;/// Sale de la funci�n menu()
            case 2:
                partida_estadisticas(); /// Estadisticas de la partida
                system("pause");
                break;
                return;/// Sale de la funci�n menu()
            case 3:
                creditos(); /// Muestra cr�ditos
                system("pause");
                return; /// Sale de la funci�n menu()
            case 0:
                cout << "Saliendo del juego..." << endl;
                exit(0); /// Termina el programa
            default:
                cout << "Opci�n invalida." << endl;
                break;
        }
    } while(true);
}

void opciones()
{
    system("cls");///Funcion para dejar limpia la consola
    cout << "+-+-+-+-+-+-+-+-+-+-" << endl;
    cout << "|      YAHTICO     |" << endl;
    cout << "+-+-+-+-+-+-+-+-+-+-" << endl;
    cout << "--------------------" << endl;
    cout << "| 1- JUGAR         |" << endl;
    cout << "| 2- ESTADISTICAS  |" << endl;
    cout << "| 3- CREDITOS      |" << endl;
    cout << "--------------------" << endl;
    cout << "| 0- SALIR         |" << endl;
    cout << "--------------------" << endl;
    cout << endl;

}
